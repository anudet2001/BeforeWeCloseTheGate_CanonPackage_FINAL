# EP01 — นักสืบกับความกล้าที่อยู่ปลายเชือก

- Format: 16:9
- Target runtime: 8:20
- Structure: 11 scenes, 39 frames
- Narrative: In Media Res → Flashback → Forest Exploration
- Main mystery: เงาปริศนา กับดัก และผู้ช่วยสีขาว
- Arc hook: ประตูรั้วไม้ใหญ่และแม่กุญแจ
- Locked reveals: โรงเรียนร้าง, Shared Memory, ห้องแล็บ

## Scene Order
S1 วิ่งตามเชือกหาทางออก
S2 เงาปริศนา
S3 กับดักและ Rabbit B ช่วยชีวิต
S4 ตราไม้และไตเติล
S5 บ้านไม้ยามเช้า
S6 กิจวัตรเช้า
S7 จัดเป้และผูกเชือกต้นแรก
S8 ระบบเชือกต่อทอด
S9 รอยเท้าปริศนา
S10 ป้อมยามร้าง
S11 ประตูรั้วและแม่กุญแจ

รายละเอียดครบทุกเฟรมอยู่ในไฟล์ CSV ภายในแพ็กเกจ
