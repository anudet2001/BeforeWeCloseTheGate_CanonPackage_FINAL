# README — Canon Package v1.0

## ไฟล์สำคัญ
- 01_Master_Story_Bible_v1.0.md: Canon ระดับซีรีส์
- 02_EP01_Canon_Overview.md: Canon ของตอนที่ 1
- 03_Character_Canon_EP01.md: คำบรรยายตัวละครฉบับใช้ใน EP01
- EP01_39Frames_ShotBreakdown_with_ImagePrompts.csv: ตาราง 39 เฟรม พร้อมมุมกล้อง เลนส์ แสง การเคลื่อนกล้อง และ Image Prompt ต่อเฟรม

## วิธีใช้
1. เปิด CSV ใน Excel โดยใช้ UTF-8
2. ตรวจ Scene Timeline Audit และ Canon Conflict ก่อนผลิต
3. ใช้ ImagePrompt_TH ทีละแถวสำหรับสร้างภาพ
4. ห้ามเข้าสู่ STEP 4/5 หากมี ERROR, FAIL Scene หรือ CCI ต่ำกว่า 90

## หมายเหตุ
Image Prompt ใช้คำบรรยายตัวละครเต็มตาม EP01 ทุกเฟรมที่ตัวละครปรากฏ


## v1.1
เพิ่ม MotionPrompt_TH แบบ Production Ready Cinematic ครบ F1-F39 โดยกำหนดการเคลื่อนไหวตัวละคร กล้อง สิ่งแวดล้อม จังหวะ และข้อกำกับความคงที่ของภาพ
