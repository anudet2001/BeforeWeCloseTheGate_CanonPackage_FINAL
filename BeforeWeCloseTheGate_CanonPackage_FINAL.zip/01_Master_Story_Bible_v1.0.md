# ก่อนที่เราจะปิดรั้ว — Master Story Bible v1.0

## Canon Hierarchy
1. Series Canon / Master Story Bible
2. Arc Bible
3. Episode Canon Script
4. Shot Breakdown
5. Prompt Package

หากข้อมูลขัดกัน เอกสารระดับสูงกว่าชนะเสมอ และระบบต้องล็อกการผลิต

## Core Premise
Route เด็กหนุ่มวัย 15 ปี สำรวจป่าโรวัลย์ข้างบ้าน พบป้อมยาม ประตูรั้ว โรงเรียนร้าง ฝูงกระต่าย และห้องแล็บโบราณ ก่อนตั้งปณิธานจะสอนกระต่ายให้พร้อมสำหรับโลกภายนอก

## Arc
- ARC 1: เข้าป่าครั้งแรก พบป้อมยาม กับดัก Rabbit B และปมแม่กุญแจ
- ARC 2: ข้ามรั้ว
- ARC 3: พบโรงเรียนร้างและ Writer Lop Rabbit
- ARC 4: ปริศนา Shared Memory
- ARC 5: ความจริงในห้องแล็บ
- ARC 6: Route สอนกระต่าย
- ARC 7: โรงเรียนกลายเป็นพื้นที่เรียนรู้

## World Canon
บ้าน Route → ชายป่า → ป่าชั้นต้น → ป่าชั้นกลาง → ป้อมยาม → ประตูรั้ว → หลังรั้ว → โรงเรียน → ป่าชั้นใน → ห้องแล็บ

## Canon Locks
- ตอนที่ 1 ห้ามเฉลยโรงเรียน Shared Memory และห้องแล็บ
- Route รู้เฉพาะข้อมูลที่ค้นพบแล้ว
- ตัวละครและสถานที่ต้องเปิดตัวตาม Timeline
- ทุกตอนมี Mystery ≥1, Clue ≥3, Red Herring ≥1 และบทสรุปอบอุ่น
- FAIL 1 Scene หรือ ERROR 1 จุด หรือ CCI < 90 เท่ากับ PRODUCTION LOCKED

## Audit Systems
Character Continuity, Knowledge Lock, Dialogue Continuity, Relationship Tracker, Location Registry, Distance Canon, Scene Timeline Audit, Clue Tracker, Mystery Tracker, Arc Tracker, Canon Conflict Detector, CCI, Canon Lock Center, Series Bible Dashboard
