# Before We Close the Gate

## EP01 Final Production Package

**ตอน:** EP01 — นักสืบกับความกล้าที่อยู่ปลายเชือก  
**Canon:** MASTER CANON | **CCI:** 96/100 | **Production:** UNLOCKED

## สารบัญ

- [ดาวน์โหลดไฟล์](#ดาวน์โหลดไฟล์)
- [ภาพรวม](#ภาพรวม)
- [โครงสร้างไฟล์](#โครงสร้างไฟล์)
- [วิธีใช้งานตามทีม](#วิธีใช้งานตามทีม)
- [สร้างและตรวจ Manifest](#สร้างและตรวจ-manifest)
- [ตรวจ Relative Links](#ตรวจ-relative-links)
- [Unit Tests](#unit-tests)
- [GitHub Actions](#github-actions)
- [SLA และ Canon Lock](#sla-และ-canon-lock)
- [สถานะ Release](#สถานะ-release)

## ดาวน์โหลดไฟล์

ลิงก์ต่อไปนี้เป็น Relative Links สำหรับ GitHub และอ้างอิงจากตำแหน่ง `README_FINAL.md` ที่ root ของ Repository

### Canon และ Production

- [ดาวน์โหลด Canon Package FINAL](Canon/BeforeWeCloseTheGate_CanonPackage_FINAL.zip)
- [เปิด Manifest](manifest.json)
- [เปิด JSON Schema](Documentation/manifest.schema.json)
- [เปิด Manifest SHA-256](Documentation/manifest.sha256)

### Executive

- [ดาวน์โหลด Executive PMO FINAL](Executive/EP01_Executive_PMO_FINAL.xlsx)
- [ดาวน์โหลด Executive Presentation FINAL](Executive/EP01_Executive_Presentation_FINAL.pptx)

### Editing

- [ดาวน์โหลด Editor Shot List FINAL](Editing/EP01_Editor_ShotList_FINAL.csv)

### Documentation และเครื่องมือ

- [อ่าน Release Notes](RELEASE_NOTES.md)
- [อ่าน Manifest Tools Guide](Documentation/README_MANIFEST_TOOLS.md)
- [เปิด build_manifest.py](Tools/build_manifest.py)
- [เปิด verify_manifest.py](Tools/verify_manifest.py)
- [เปิด check_readme_links.py](Tools/check_readme_links.py)
- [เปิด Unit Tests](tests/test_manifest_tools.py)
- [เปิด GitHub Actions Workflow](.github/workflows/verify-manifest.yml)
- [เปิด requirements.txt](requirements.txt)

## ภาพรวม

แพ็กเกจนี้รวม Story Canon, Episode Canon, 39-frame Production CSV, Prompt ทั้งสามประเภท, Editing Package, Executive PMO, QC, SLA, RACI และชุดเครื่องมือ CI/CD

## โครงสร้างไฟล์

```text
BeforeWeCloseTheGate_EP01_FINAL_PACKAGE/
├── README_FINAL.md
├── RELEASE_NOTES.md
├── manifest.json
├── requirements.txt
├── Canon/
│   └── BeforeWeCloseTheGate_CanonPackage_FINAL.zip
├── Executive/
│   ├── EP01_Executive_PMO_FINAL.xlsx
│   └── EP01_Executive_Presentation_FINAL.pptx
├── Editing/
│   └── EP01_Editor_ShotList_FINAL.csv
├── Documentation/
│   ├── README_MANIFEST_TOOLS.md
│   ├── manifest.schema.json
│   └── manifest.sha256
├── Tools/
│   ├── build_manifest.py
│   ├── verify_manifest.py
│   └── check_readme_links.py
├── tests/
│   └── test_manifest_tools.py
└── .github/workflows/
    └── verify-manifest.yml
```

รายการไฟล์ ขนาด และ checksum ที่เป็นแหล่งอ้างอิงจริงอยู่ใน [manifest.json](manifest.json)

## วิธีใช้งานตามทีม

- **ผู้บริหาร:** เปิด [Executive PMO](Executive/EP01_Executive_PMO_FINAL.xlsx) และ [Presentation](Executive/EP01_Executive_Presentation_FINAL.pptx)
- **ทีม Canon/Writer:** ใช้ [Canon Package](Canon/BeforeWeCloseTheGate_CanonPackage_FINAL.zip)
- **ทีมตัดต่อ:** ใช้ [Editor Shot List](Editing/EP01_Editor_ShotList_FINAL.csv)
- **ทีม QA/CI:** ใช้เครื่องมือใน `Tools/`, ชุดทดสอบ และ Workflow

## สร้างและตรวจ Manifest

```bash
python -m pip install -r requirements.txt
python Tools/build_manifest.py . --validate
python Tools/verify_manifest.py . --strict
```

รายงาน JSON:

```bash
python Tools/build_manifest.py . --validate --json
python Tools/verify_manifest.py . --strict --json
```

## ตรวจ Relative Links

ตรวจ README ทั้งสองไฟล์และ Anchor ในสารบัญ:

```bash
python Tools/check_readme_links.py \
  README_FINAL.md \
  Documentation/README_MANIFEST_TOOLS.md
```

รายงานแบบ JSON:

```bash
python Tools/check_readme_links.py README_FINAL.md --json
```

## Unit Tests

```bash
python -m unittest discover -s tests -v
```

## GitHub Actions

Workflow ที่ [.github/workflows/verify-manifest.yml](.github/workflows/verify-manifest.yml) รองรับ Push, Pull Request, Manual Run และ Python 3.10, 3.11, 3.12, 3.13 โดยรัน Unit Tests, Relative Link Check, Manifest Build และ Strict Verification

## SLA และ Canon Lock

- `At Risk` คือ 20% สุดท้ายของ SLA
- Canon Conflict, Lost Clue, Scene FAIL หรือ CCI ต่ำกว่า 90 ทำให้ `PRODUCTION LOCKED`

## สถานะ Release

```text
CANON STATUS      : MASTER CANON
CCI               : 96 / 100
RISK LEVEL        : LOW
PRODUCTION STATUS : UNLOCKED
RELEASE STATUS    : READY FOR EXECUTIVE SIGN-OFF
```
