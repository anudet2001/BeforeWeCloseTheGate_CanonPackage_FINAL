#!/usr/bin/env python3
"""Check local relative links and table-of-contents anchors in Markdown files."""
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path
from urllib.parse import unquote

LINK_RE = re.compile(r'(?<!!)\[[^\]]+\]\(([^)]+)\)')
HEADING_RE = re.compile(r'^(#{1,6})\s+(.+?)\s*#*$', re.MULTILINE)

def slugify(text: str) -> str:
    text = re.sub(r'<[^>]+>', '', text).strip().lower()
    text = re.sub(r'[`*_~]', '', text)
    text = re.sub(r'[^\w\-\s\u0E00-\u0E7F]', '', text)
    return re.sub(r'[\s_]+', '-', text).strip('-')

def check_file(md: Path) -> dict:
    text=md.read_text(encoding='utf-8')
    anchors={slugify(m.group(2)) for m in HEADING_RE.finditer(text)}
    checked=[]; failures=[]
    for raw in LINK_RE.findall(text):
        target=raw.strip().split()[0].strip('<>')
        if target.startswith(('http://','https://','mailto:')): continue
        if target.startswith('#'):
            anchor=unquote(target[1:])
            ok=anchor in anchors
            item={'link':raw,'type':'anchor','resolved':anchor,'status':'PASS' if ok else 'FAIL'}
        else:
            file_part,_,fragment=target.partition('#')
            resolved=(md.parent/unquote(file_part)).resolve()
            ok=resolved.exists()
            if ok and fragment and resolved.suffix.lower()=='.md':
                other=resolved.read_text(encoding='utf-8')
                other_anchors={slugify(m.group(2)) for m in HEADING_RE.finditer(other)}
                ok=unquote(fragment) in other_anchors
            item={'link':raw,'type':'relative','resolved':str(resolved),'status':'PASS' if ok else 'FAIL'}
        checked.append(item)
        if not ok: failures.append(item)
    return {'file':str(md),'checked':len(checked),'failed':len(failures),'failures':failures,'links':checked}

def main():
    p=argparse.ArgumentParser(); p.add_argument('files',nargs='+',type=Path); p.add_argument('--json',action='store_true')
    a=p.parse_args(); reports=[]
    for f in a.files:
        if not f.is_file(): reports.append({'file':str(f),'checked':0,'failed':1,'failures':[{'link':str(f),'status':'FAIL','reason':'file_missing'}],'links':[]})
        else: reports.append(check_file(f.resolve()))
    failed=sum(r['failed'] for r in reports); result={'tool':'check_readme_links.py','result':'PASS' if failed==0 else 'FAIL','files_checked':len(reports),'links_checked':sum(r['checked'] for r in reports),'failed_links':failed,'reports':reports,'exit_code':0 if failed==0 else 1}
    if a.json: print(json.dumps(result,ensure_ascii=False,indent=2))
    else:
        for r in reports: print(f"{r['file']}: {r['checked']} links, {r['failed']} failed")
        print(f"RESULT: {result['result']}")
    return result['exit_code']
if __name__=='__main__': raise SystemExit(main())
